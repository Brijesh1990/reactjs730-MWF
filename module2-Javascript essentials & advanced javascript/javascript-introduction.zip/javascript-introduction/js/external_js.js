alert('i am just load flipkart click on OK')
window.location='https://www.flipkart.com';